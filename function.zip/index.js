// AWS SDKをimport
const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient({
  region: process.env.AWS_REGION_NAME // DynamoDBのリージョン
});

exports.handler = async event => {
    let limit = 3
    
    const params = {
        TableName: "geekLaundrySystem",
        limit: limit,
        ScanIndexForward: false,
    };
    try {
        const result = await dynamoDB.scan(params).promise();
        return {
        statusCode: 200,
        body: JSON.stringify(result),
        };
    } catch (error) {
        return {
        statusCode: error.statusCode,
        body: error.message,
        };
    }
};